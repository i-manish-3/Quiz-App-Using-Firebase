package com.example.quizzer;

import android.app.Activity;

public class signupActivity extends Activity {
}
